package com.example.myapplication345;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import android.content.SharedPreferences.Editor;

import static androidx.core.content.ContextCompat.startActivity;


public class MainActivity extends AppCompatActivity {


    private EditText edtuname;
    private EditText edtpassword;



    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtuname = (EditText) findViewById(R.id.edt_email);
        edtpassword = (EditText) findViewById(R.id.edt_password);



        Button btn = (Button) findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View view) {


                String struname = edtuname.getText().toString();
                String strpassword = edtpassword.getText().toString();
                if (struname.equals("")) {

                    //Toast.makeText(MainActivity.this, "Enter Email ID", Toast.LENGTH_SHORT).show();
                    edtuname.setError("Enter Email ID");
                }
                else if(!struname.matches(emailPattern)) {
                    edtuname.setError("Enter valid Email address");
                }
                else if (strpassword.equals("")) {
                    //Toast.makeText(MainActivity.this, "Enter Password ", Toast.LENGTH_SHORT).show();
                    edtpassword.setError("Enter password");
                }
                else
                {


                    SharedPreferences sharedPreferences = getSharedPreferences("MyApplication345",Context.MODE_PRIVATE);

                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("User_email",struname);

                    editor.commit();

                    Intent i = new Intent(MainActivity.this, NavMain.class);
                    startActivity(i);

                    finish();





                    startActivity(new Intent(MainActivity.this,NavMain.class));
                    Toast.makeText(MainActivity.this, "Logged in successfully", Toast.LENGTH_SHORT).show();

                }


            }});


        Button btn1 = (Button) findViewById(R.id.button1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Signup_Form.class));
            }

        });
    }




}
