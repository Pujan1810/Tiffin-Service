package com.example.myapplication345;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Signup_Form extends AppCompatActivity {

    private EditText edtfname;
    private EditText edtlname;
    private EditText edtemailid;
    private EditText edtpasswd;
    private EditText edtphonenumber;
    final String emailPattern1 = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    final String num = "[0-9]";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup__form);

        edtfname = (EditText)findViewById(R.id.edt_fname);
        edtlname = (EditText)findViewById(R.id.edt_lname);
        edtemailid = (EditText) findViewById(R.id.edt_emailid);
        edtpasswd = (EditText)  findViewById(R.id.edt_passwd);
        edtphonenumber= (EditText) findViewById(R.id.edt_phonenumber);

        Button btn2 = (Button) findViewById(R.id.button2);
        btn2.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {





                String strfname = edtfname.getText().toString();
                String strlname = edtlname.getText().toString();
                String stremailid = edtemailid.getText().toString();
                String strpasswd = edtpasswd.getText().toString();
                String strphone= edtphonenumber.getText().toString();

                if(strfname.equals(""))
                {
                    Toast.makeText(Signup_Form.this,"Enter First Name",Toast.LENGTH_SHORT).show();

                }

                else if(strlname.equals(""))
                {
                    Toast.makeText(Signup_Form.this,"Enter Last Name",Toast.LENGTH_SHORT).show();

                }

                else if(stremailid.equals(""))
                {
                    Toast.makeText(Signup_Form.this,"Enter Email ID",Toast.LENGTH_SHORT).show();

                }
                else if(!stremailid.matches(emailPattern1))
                {
                    Toast.makeText(Signup_Form.this,"Enter valid Email Id",Toast.LENGTH_SHORT).show();
                }
                else if(strphone.equals(""))
                {
                    Toast.makeText(Signup_Form.this,"Enter Phone Number",Toast.LENGTH_SHORT).show();

                }
                else if(strphone.length()<10)
                {
                    Toast.makeText(Signup_Form.this,"Enter Valid Phone Number",Toast.LENGTH_SHORT).show();
                }
                else if(strpasswd.equals(""))
                {
                    Toast.makeText(Signup_Form.this,"Enter Password",Toast.LENGTH_SHORT).show();

                }
                else
                {
                    Toast.makeText(Signup_Form.this,"Signed up Successfully",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Signup_Form.this, NavMain.class));

                    SharedPreferences sharedPreferences = getSharedPreferences("MyApplication345", Context.MODE_PRIVATE);

                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("User_fname",strfname);
                    editor.putString("User_email1",stremailid);
                    editor.putString("User_lname",strlname);
                    editor.putString("User_contact_no",strphone);
                    editor.putString("User_password",strpasswd);
                    editor.commit();

                    Intent i = new Intent(Signup_Form.this, NavMain.class);
                    startActivity(i);

                    finish();


                }





            }
        });
    }


}
